//  ========================================
//  Name: Edward (Eddie) Guo
//  ID: 1576381
//  Partner: Jason Kim
//  CMPUT 275, Winter 2020
//
//  Assignment 2 Part 1: Directions (Server)
//  ========================================

#ifndef _POINTS_H_
#define _POINTS_H_

// stores a point read from the map in 100,000-ths of a degree as integers
struct Point {
	long long lat;
	long long lon;
};

#endif
