//  ========================================
//  Name: Edward (Eddie) Guo
//  ID: 1576381
//  CMPUT 275, Winter 2020
//
//  Weekly Exercise 1: Display and Joystick
//  ========================================

#include <Arduino.h>
#include <Adafruit_GFX.h>
#include <MCUFRIEND_kbv.h>
#include <SPI.h>
#include <SD.h>
#include "lcd_image.h"

MCUFRIEND_kbv tft;

// pins to connect
#define SD_CS 10
#define JOY_VERT A9
#define JOY_HORIZ A8
#define JOY_SEL 53
// screen and map dimensions
#define DISPLAY_WIDTH 480
#define DISPLAY_HEIGHT 320
#define PADX 60
#define YEG_SIZE 2048
lcd_image_t yegImage = { "yeg-big.lcd", YEG_SIZE, YEG_SIZE };
// joystick movement
#define JOY_CENTER 512
#define JOY_DEADZONE 64
// cursor size and position
#define CURSOR_SIZE 9
int cursorX, cursorY;


// function declarations
void setup();
void lcd_setup();
void redrawCursor(uint16_t);
void processJoystick(uint8_t, uint8_t);
void drawMapPatch(int, int);
void constrainCursor(int*, int*);
void lcdYegDraw(int, int, int, int, int, int);


/*
  Description: moves a cursor across a partial map of Edmonton using a joystick
    on a TFT display controlled by an Arduino.
*/
int main() {
  setup();
  lcd_setup();

  while (true) {
    // min and max cursor speeds are 0 and CURSOR_SIZE pixels/cycle respectively
    processJoystick(0, CURSOR_SIZE);
  }

  Serial.end();
  return 0;
}


/*
  Description: initializes important components of Arduino and TFT display.
*/
void setup() {
  init();
  Serial.begin(9600);
  pinMode(JOY_SEL, INPUT_PULLUP);

  uint16_t ID = tft.readID();
  Serial.print("ID = 0x");
  Serial.println(ID, HEX);
  if (ID == 0xD3D3) ID = 0x9481;
  tft.begin(ID);

  Serial.print("Initializing SD card...");
  if (!SD.begin(SD_CS)) {
    Serial.println("failed! Is it inserted properly?");
    while (true) {}
  }
  Serial.println("OK!");
}


/*
  Description: intializes TFT display. Portrait display, draws the centre of the
    Edmonton map with the rightmost 60 pixels black, and sets the initial cursor
    position to the middle of the map.
*/
void lcd_setup() {
  tft.setRotation(1);
  tft.fillScreen(TFT_BLACK);
  // drawing map
  int yegMiddleX = (YEG_SIZE - (DISPLAY_WIDTH - PADX)) >> 1;
  int yegMiddleY = (YEG_SIZE - DISPLAY_HEIGHT) >> 1;
  lcd_image_draw(&yegImage, &tft, yegMiddleX, yegMiddleY, 0, 0,
    DISPLAY_WIDTH - PADX, DISPLAY_HEIGHT);
  // setting cursor to middle of YEG map
  cursorX = (DISPLAY_WIDTH - PADX) >> 1;
  cursorY = DISPLAY_HEIGHT >> 1;
  redrawCursor(TFT_RED);
}


/*
  Description: translates joystick inputs to movement of the cursor on the TFT
    screen. Constrains the cursor to within the map portion of the screen, and
    sets variable speed.

  Arguments:
    slow (uint8_t): the minimum cursor speed (pixels/loop).
    fast (uint8_t): the maximum cursor speed (pixels/loop).
*/
void processJoystick(uint8_t slow, uint8_t fast) {
  uint16_t xVal = analogRead(JOY_HORIZ);
  uint16_t yVal = analogRead(JOY_VERT);
  uint16_t EPSILON_POS = JOY_CENTER + JOY_DEADZONE;
  uint16_t EPSILON_NEG = JOY_CENTER - JOY_DEADZONE;
  uint16_t MAX_STICK = (1 << 10) - 1;

  // store current cursor position
  int cursorX0 = cursorX, cursorY0 = cursorY;
  // x movement
  if (xVal > EPSILON_POS) {
    cursorX -= map(xVal, EPSILON_POS, MAX_STICK, slow, fast);
  } else if (xVal < EPSILON_NEG) {
    cursorX += map(xVal, 0, EPSILON_NEG, fast, slow);
  }
  // y movement
  if (yVal < EPSILON_NEG) {
    cursorY -= map(yVal, 0, EPSILON_NEG, fast, slow);
  } else if (yVal > EPSILON_POS) {
    cursorY += map(yVal, EPSILON_POS, MAX_STICK, slow, fast);
  }

  // constrain cursor within the map
  constrainCursor(&cursorX, &cursorY);
  if (cursorX0 != cursorX || cursorY != cursorY0) {
    drawMapPatch(cursorX0, cursorY0);
    redrawCursor(TFT_RED);
  }
  delay(20);
}


/*
  Description: constrains the cursor within the boundaries of the image
    displayed on the TFT display. This function assumes the cursor is a square.

  Arguments:
    cursorX (int*): the value stored at the memory location of the cursor's X
      position.
    cursorY (int*): the value stored at the memory location of the cursor's Y
      position.
*/
void constrainCursor(int* cursorX, int* cursorY) {
  // PAD accounts for integer division by 2 (i.e., cursor has odd sidelength)
  uint8_t PAD = 0;
  if (CURSOR_SIZE & 1) PAD = 1;

  *cursorX = constrain(*cursorX, (CURSOR_SIZE >> 1),
    DISPLAY_WIDTH - PADX - (CURSOR_SIZE >> 1) - PAD);
  *cursorY = constrain(*cursorY, (CURSOR_SIZE >> 1),
    DISPLAY_HEIGHT - (CURSOR_SIZE >> 1) - PAD);
}


/*
  Description: draws a square cursor at the current cursor position.

  Arguments:
    colour (uint16_t): the colour of the cursor.
*/
void redrawCursor(uint16_t colour) {
  tft.fillRect(cursorX - (CURSOR_SIZE >> 1), cursorY - (CURSOR_SIZE >> 1),
    CURSOR_SIZE, CURSOR_SIZE, colour);
}


/*
  Description: draws a small map patch from the old cursor position up to the
    new cursor position (i.e., only redraws a rectangle if the cursor did not
    move too much).

  Arguments:
    cursorX0 (uint16_t): the original cursor's X position.
    cursorY0 (uint16_t): the original cursor's Y position.
*/
void drawMapPatch(int cursorX0, int cursorY0) {
  // middle of the YEG map
  int yegMiddleX = (YEG_SIZE - (DISPLAY_WIDTH - PADX)) >> 1;
  int yegMiddleY = (YEG_SIZE - DISPLAY_HEIGHT) >> 1;
  // storing change in cursor position
  int diffX = cursorX - cursorX0;
  int diffY = cursorY - cursorY0;
  // storing appropriate irow and icol positions
  int icolPos = yegMiddleX + cursorX0 + (CURSOR_SIZE >> 1) + diffX;
  int icolNeg = yegMiddleX + cursorX0 - (CURSOR_SIZE >> 1);
  int irowPos = yegMiddleY + cursorY0 + (CURSOR_SIZE >> 1) + diffY;
  int irowNeg = yegMiddleY + cursorY0 - (CURSOR_SIZE >> 1);
  // storing appropriate srow and scol positions
  int scolPos = cursorX + (CURSOR_SIZE >> 1);
  int scolNeg = cursorX0 - (CURSOR_SIZE >> 1);
  int srowPos = cursorY + (CURSOR_SIZE >> 1);
  int srowNeg = cursorY0 - (CURSOR_SIZE >> 1);
  // PAD accounts for integer division by 2 (i.e., cursor has odd sidelength)
  uint8_t PAD = 0;
  if (CURSOR_SIZE & 1) PAD = 1;

  // draw the cursor
  if (diffX == 0 && diffY < 0) {
      // up
      lcdYegDraw(icolNeg, irowPos, scolNeg, srowPos, CURSOR_SIZE, -diffY + PAD);
  } else if (diffX == 0 && diffY > 0) {
      // down
      lcdYegDraw(icolNeg, irowNeg, scolNeg, srowNeg, CURSOR_SIZE, diffY);
  } else if (diffX < 0 && diffY == 0) {
      // left
      lcdYegDraw(icolPos, irowNeg, scolPos, srowNeg, -diffX + PAD, CURSOR_SIZE);
  } else if (diffX > 0 && diffY == 0) {
      // right
      lcdYegDraw(icolNeg, irowNeg, scolNeg, srowNeg, diffX, CURSOR_SIZE);
  } else if (diffY < 0 && diffX < 0) {
      // up and left
      lcdYegDraw(icolPos, irowNeg, scolPos, srowNeg, -diffX + PAD, CURSOR_SIZE);
      lcdYegDraw(icolNeg, irowPos, scolNeg, srowPos, CURSOR_SIZE, -diffY + PAD);
  } else if (diffY < 0 && diffX > 0) {
      // up and right
      lcdYegDraw(icolNeg, irowNeg, scolNeg, srowNeg, diffX, CURSOR_SIZE);
      lcdYegDraw(icolNeg, irowPos, scolNeg, srowPos, CURSOR_SIZE, -diffY + PAD);
  } else if (diffY > 0 && diffX < 0) {
      // down and left
      lcdYegDraw(icolPos, irowNeg, scolPos, srowNeg, -diffX + PAD, CURSOR_SIZE);
      lcdYegDraw(icolNeg, irowNeg, scolNeg, srowNeg, CURSOR_SIZE, diffY);
  } else {
      // down and right
      lcdYegDraw(icolNeg, irowNeg, scolNeg, srowNeg, diffX, CURSOR_SIZE);
      lcdYegDraw(icolNeg, irowNeg, scolNeg, srowNeg, CURSOR_SIZE, diffY);
  }
}


/*
  Description: helper function for drawMapPatch(). Essentially the
    lcd_image_draw() except it assumes the image's memory address is &yegImage
    and the TFT object's memory address is &tft.

  Arguments:
    icol (int): image column.
    irow (int): image row.
    scol (int): screen column.
    srow (int): screen row.
    width (int): width of the patch to draw.
    height (int): height of the patch to draw.
*/
void lcdYegDraw(int icol, int irow, int scol, int srow, int width, int height) {
  lcd_image_draw(&yegImage, &tft, icol, irow, scol, srow, width, height);
}
